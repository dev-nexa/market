<div class="modal fade" id="note_modal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content" id="note_modal_content">

        </div>
    </div>
</div>