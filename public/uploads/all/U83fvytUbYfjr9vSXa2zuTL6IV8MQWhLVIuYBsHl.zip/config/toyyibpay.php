<?php

return [

  'key' => env('TOYYIBPAY_KEY', ''),
  'category' => env('TOYYIBPAY_CATEGORY', '')


];

